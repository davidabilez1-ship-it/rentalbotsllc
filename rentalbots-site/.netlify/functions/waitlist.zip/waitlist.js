exports.handler = async function(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  let email;
  try {
    const body = JSON.parse(event.body);
    email = body.email;
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  if (!email || !email.includes("@")) {
    return { statusCode: 400, body: JSON.stringify({ error: "Valid email required" }) };
  }

  const MAILCHIMP_API_KEY = process.env.MAILCHIMP_API_KEY;
  const MAILCHIMP_AUDIENCE_ID = process.env.MAILCHIMP_AUDIENCE_ID;

  if (!MAILCHIMP_API_KEY || !MAILCHIMP_AUDIENCE_ID) {
    console.error("Missing env vars:", { MAILCHIMP_API_KEY: !!MAILCHIMP_API_KEY, MAILCHIMP_AUDIENCE_ID: !!MAILCHIMP_AUDIENCE_ID });
    return { statusCode: 500, body: JSON.stringify({ error: "Missing Mailchimp configuration" }) };
  }

  try {
    const response = await fetch(`https://us4.api.mailchimp.com/3.0/lists/${MAILCHIMP_AUDIENCE_ID}/members`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `apikey ${MAILCHIMP_API_KEY}`,
      },
      body: JSON.stringify({
        email_address: email,
        status: "subscribed",
        merge_fields: {},
      }),
    });

    const data = await response.json();

    if (response.ok) {
      console.log("✅ Successfully added to Mailchimp:", email);
      return { statusCode: 200, body: JSON.stringify({ message: "success" }) };
    } else {
      console.error("❌ Mailchimp API error:", data);
      return { statusCode: 400, body: JSON.stringify({ error: data.title || "Mailchimp error" }) };
    }
  } catch (err) {
    console.error("❌ Network/unknown error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: "Failed to connect to Mailchimp" }) };
  }
};